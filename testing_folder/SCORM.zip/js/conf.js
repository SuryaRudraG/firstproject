const mySubDomain = "https://cnets-teach.gitlab.io";
const mySiteBase = "https://cnets-teach.gitlab.io/cmich-itc-630/content";
const myFolder = "3_servicemodels";
const mySiteURL = mySiteBase + "/" + myFolder;


new


newline2